<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\News;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\CategoryController;

class IndexController extends Controller
{
    public function index()
    {
        return view('admin.index');
    }

    public function create(Request $request, Category $category)
    {
        if ($request->isMethod('post')) {
            // TODO Прочитать файл json
            $file = file_get_contents('NewsRepos.json');
            $array = json_decode($file, TRUE);
            $req = $request->all();
            $req = array_slice($req, 1);
            $count_array = (count($array));
            $req['id'] = $count_array + 1;
            $array[] = $req;
//            $json = json_encode($array, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
//            $e = file_put_contents(__DIR__ . '/../../../../public/NewsRepos.json', $json);
            Storage::disk('local')
                ->put('news.json', json_encode($array, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            //добавить в массив новую новость
            //записать все новости обратно в файл
            //сделать редирект на эту новость
            $request->flash();
            return redirect()->route('news.show',$count_array + 1);
            //dd($request->except('_token'));
        }
        return view('admin.create', [
            'categories' => $category->getCategories()
        ]);
    }

    public function test1()
    {
        return response()->download('1.jpg');
    }

    public function test2(Category $category)
    {
        return view('admin.test2')
            ->with('categories', $category->getCategories());
    }

    public function downloadCategory(News $news, $slug)
    {
        return response()->json($news->getNewsByCategorySlug($slug))
            ->header('Content-Disposition', 'attachment; filename = "json.json"')
            ->setEncodingOptions(JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
//        redirect()->route('admin.index', ); TODO Как сделать после этого редирект подскажите пожалуйста
    }

}
