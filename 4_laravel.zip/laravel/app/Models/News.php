<?php

namespace App\Models;

use Illuminate\Support\Facades\Storage;

class News
{
    private Category $category;

    public function __construct(Category $category)
    {
        $this->category = $category;
    }

    public function getNewsByCategorySlug($slug): array
    {
        $id = $this->category->getCategoryIdBySlug($slug);
        $news = [];
        foreach ($this->getNews() as $item) {
            if ($item['category_id'] == $id) {
                $news[] = $item;
            }
        }
        return $news;
    }

    public function getNews(): array
    {
       return json_decode((Storage::disk('local')->get('news.json')),true);
//        dd(json_decode(Storage::disk('local')->get('news.json'), true));
//        $file = file_get_contents('NewsRepos.json');  // Открыть файл .json
//        dd($file);
//        return json_decode($file, TRUE); // Декодировать в массив
    }


    public function getNewsId($id): ?array
    {
        if (array_key_exists($id, $this->getNews())) {
            return $this->getNews()[$id];
        }
        return null;
    }
}
