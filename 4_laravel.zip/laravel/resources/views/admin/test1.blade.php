@extends('layouts.app')

@section('title')
    @parent Админка
@endsection

@section ('menu')
    @include('admin.menu')
@endsection
