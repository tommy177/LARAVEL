<li class="nav-item">
    <a class="nav-link" href="{{ route('home') }}">Главная Сайт</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="{{ route('admin.index') }}">Главная Админка</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="{{ route('admin.create') }}">Создать новость</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="{{ route('admin.test1') }}">Скачать изображение</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="{{ route('admin.test2') }}">Скачать текст</a>
</li>

