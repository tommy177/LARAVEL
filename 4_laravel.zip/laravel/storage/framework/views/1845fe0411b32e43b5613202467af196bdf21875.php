<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('home')); ?>">Главная Сайт</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Главная Админка</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.create')); ?>">Создать новость</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.test1')); ?>">Скачать изображение</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.test2')); ?>">Скачать текст</a>
</li>

<?php /**PATH C:\OSPanel\domains\laravel\resources\views/admin/menu.blade.php ENDPATH**/ ?>